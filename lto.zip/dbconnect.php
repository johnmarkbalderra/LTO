<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");

$servername = "fdb1029.awardspace.net";
$username = "4564847_land";
$password = "landlto123";
$dbname = "4564847_land";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    http_response_code(500); // Set error response code
    echo json_encode(["status" => "error", "message" => "Connection failed: " . $conn->connect_error]);
    exit();
}

echo json_encode(["status" => "success", "message" => "Connected successfully!"]);
?>
